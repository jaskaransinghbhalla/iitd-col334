#include <chrono>
#include <iostream>

using namespace std;

int main() {
    
    auto current_time = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
    // auto current_time2 = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();
    // auto current_time3 = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());

    cout << "Current time millis " << current_time << endl;
    cout << "Current time current time 2 (high system clock)" << current_time2 << endl;
    // cout << "Current time current time 3 (system clock)" << current_time3 << endl;

    return 0;
}