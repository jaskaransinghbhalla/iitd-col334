1. Shutdown the server after all the client requests have ended
2. Implement the k and words per offset send along with `ceil(k/p)` packets being send
3. Nothing is send by the server